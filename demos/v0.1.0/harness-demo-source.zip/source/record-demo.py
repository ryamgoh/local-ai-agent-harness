#!/usr/bin/env python3
"""Run a paced, real CLI walkthrough; record stdout with asciinema, never upload it."""
import codecs
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / 'workspace'
STATE = WORK / 'state'
PREFIX = ROOT / 'runtime'
PACKAGE = PREFIX / 'lib/node_modules/local-ai-agent-harness'
WORK.mkdir(exist_ok=True)
os.chdir(WORK)
env = dict(os.environ)
env.update({'PATH': str(PREFIX / 'bin') + ':' + env.get('PATH', ''), 'NPM_CONFIG_PREFIX': str(PREFIX), 'HARNESS_HOME': str(STATE), 'TERM': 'xterm-256color'})
env.pop('HARNESS_MODEL', None)
env['PLUGINS'] = str(PACKAGE / 'plugins')
secret = env.get('OPENROUTER_API_KEY')
if not secret:
    raise SystemExit('OPENROUTER_API_KEY is required for the live-inference scene.')
start = time.monotonic()
chapters = []
results = []
CYAN = '\033[96m'
GREEN = '\033[92m'
DIM = '\033[90m'
BOLD = '\033[1m'
END = '\033[0m'


def write(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def pause(seconds=3):
    if not os.environ.get('DEMO_FAST'):
        time.sleep(seconds)


def scene(number, title, subtitle):
    write('\033[2J\033[H\033[?25l')
    write(f'{DIM}LOCAL AI AGENT HARNESS  /  v0.1.0  /  REAL CLI RECORDING{END}\n')
    write(f'{BOLD}{CYAN}{number:02d}  {title}{END}\n')
    write(f'{DIM}{subtitle}{END}\n\n')
    chapters.append({'time': round(time.monotonic() - start, 3), 'title': title})
    pause(2)


def type_command(command):
    lines = command.split('\n')
    for i, line in enumerate(lines):
        write(f'{GREEN}{"$ " if i == 0 else "> "}{END}')
        for character in line:
            write(character)
            if not os.environ.get('DEMO_FAST'):
                time.sleep(0.012)
        write('\n')
    pause(0.35)


def run(command, expected=0, hold=3):
    type_command(command)
    began = time.monotonic()
    process = subprocess.Popen(['/bin/bash', '-c', command], env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    decoder = codecs.getincrementaldecoder('utf8')()
    output = ''
    # Keep a credential-length tail so an accidental secret is masked even across chunks.
    pending = ''
    while True:
        chunk = process.stdout.read1(4096)
        if not chunk:
            break
        pending += decoder.decode(chunk)
        pending = pending.replace(secret, '[CREDENTIAL REDACTED]')
        keep = max(0, len(pending) - len(secret))
        if keep:
            text, pending = pending[:keep], pending[keep:]
            output += text
            write(text)
    pending += decoder.decode(b'', final=True)
    pending = pending.replace(secret, '[CREDENTIAL REDACTED]')
    output += pending
    write(pending)
    status = process.wait(timeout=120)
    if not output.endswith('\n'):
        write('\n')
    results.append({'command': command, 'exitCode': status, 'expectedExitCode': expected, 'duration': round(time.monotonic() - began, 3), 'output': output})
    if status != expected:
        raise RuntimeError(f'Demo command failed: expected {expected}, got {status}: {command}')
    pause(hold)
    return output


WORK.mkdir(exist_ok=True)
if STATE.exists():
    shutil.rmtree(STATE)
try:
    scene(1, 'A small host. Zero built-in tools.', 'Actual released package, installed with npm. Isolated state in a Linux sandbox.')
    assert run('harness --version', hold=1.5).strip() == '0.1.0'
    run('export HARNESS_HOME="$PWD/state"\nexport PLUGINS="$(npm root -g)/local-ai-agent-harness/plugins"', hold=1)
    assert 'No tools' in run('harness tools list', hold=3)
    write(f'\n{CYAN}Capabilities appear only when a plugin is enabled.{END}\n')
    pause(3)

    scene(2, 'A Python plugin adds MCP tools.', '--yes below approves these already-reviewed proof plugins, not arbitrary plugin code.')
    run('harness plugin install "$PLUGINS/notes" --yes', hold=3)
    run('harness plugin config notes set \\\n  "notesDir=$HARNESS_HOME/data/notes" maxResults=5', hold=1.5)
    tools = run('harness tools list', hold=5)
    assert all(name in tools for name in ['notes.read', 'notes.write', 'notes.search'])

    scene(3, 'A Node policy plugin composes with Python.', 'The guard hook rewrites tool input before notes.write executes. The token is synthetic.')
    run('harness plugin install "$PLUGINS/guard" --yes', hold=3)
    run('harness tools call notes.write --yes --input \\\n  \'{"path":"offsite.md","content":"Offsite: Lisbon on 14 May. Rotate key sk-demo1234567890"}\'', hold=4)
    run('cat "$HARNESS_HOME/data/notes/offsite.md"', hold=6)
    content = (STATE / 'data/notes/offsite.md').read_text()
    assert '[REDACTED]' in content and 'sk-demo1234567890' not in content

    scene(4, 'Policy denial wins, even with --yes.', 'No side effect: blocked.md must never be created.')
    run('harness plugin config guard set \'deny=["notes.write"]\'', hold=1.5)
    blocked = run('harness tools call notes.write --yes --input \\\n  \'{"path":"blocked.md","content":"This must not be saved."}\'', expected=1, hold=5)
    assert 'blocked by guard' in blocked
    assert not (STATE / 'data/notes/blocked.md').exists()
    run('test ! -e "$HARNESS_HOME/data/notes/blocked.md" \\\n  && echo "Confirmed: blocked.md does not exist."', hold=3)
    run('harness plugin config guard set \'deny=[]\'', hold=1)

    scene(5, 'A real agent uses the discovered tools.', 'Live OpenRouter inference through the Vercel AI SDK. Only a credential variable name is shown.')
    run('harness config set model.provider openai-compatible\nharness config set model.baseURL https://openrouter.ai/api/v1\nharness config set model.id openai/gpt-4.1-mini\nharness config set model.apiKeyEnv OPENROUTER_API_KEY', hold=2)
    answer = run('harness run \\\n  "Search notes for offsite. Where and when is it? Use the tool; answer in one sentence." \\\n  --max-steps 6', hold=8)
    assert 'Tool: notes.search' in answer, 'The real model did not use the required search tool.'
    assert 'Lisbon' in answer and '14 May' in answer

    scene(6, 'Disable the plugin. The tools disappear.', 'The host is unchanged: plugin lifecycle controls which capabilities the model receives.')
    run('harness plugin disable notes', hold=1.5)
    assert 'No tools' in run('harness tools list', hold=3)
    run('harness plugin enable notes', hold=1.5)
    tools = run('harness tools list', hold=4)
    assert all(name in tools for name in ['notes.read', 'notes.write', 'notes.search'])

    scene(7, 'Local-first host. Language-independent plugins.', 'MCP tool discovery + JSON hooks + one guarded execution gateway.')
    write(f'{GREEN}Demonstrated on the actual v0.1.0 release:{END}\n\n')
    write('  Python notes adds three MCP tools.\n')
    write('  Node guard redacts and denies tool calls.\n')
    write('  Live OpenRouter inference finds the saved note.\n')
    write('  Disable removes tools; enable restores them.\n\n')
    write(f'{DIM}Model is hosted in this recording; the host and plugins run locally.\n')
    write('Ollama is supported but not demonstrated here.\n')
    write('Declared permissions are consent information, not an OS sandbox.\n\n')
    write('Private repository: ryamgoh/local-ai-agent-harness\n')
    write('Install guide: docs/INSTALL.md    Release: v0.1.0\n')
    write('Recorded commands are real. Command typing is scripted for readability.\n'+END)
    pause(7)
    write('\033[?25h')
    report = {'packageVersion': '0.1.0', 'platform': 'Linux sandbox', 'modelProvider': 'OpenRouter', 'model': 'openai/gpt-4.1-mini', 'scriptedInference': False, 'duration': round(time.monotonic() - start, 3), 'chapters': chapters, 'commands': results, 'assertionsPassed': True, 'credentialRecorded': False}
    (ROOT / 'source/demo-evidence.json').write_text(json.dumps(report, indent=2)+'\n')
except Exception:
    write('\033[?25h')
    raise
