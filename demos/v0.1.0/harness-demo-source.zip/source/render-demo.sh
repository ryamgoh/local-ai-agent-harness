#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
AGG="${AGG:-$ROOT/tools/agg}"
CAST="$ROOT/local-ai-agent-harness.cast"
export RAYON_NUM_THREADS=4
printf 'Rendering real terminal frames with agg...\n'
"$AGG" "$CAST" "$ROOT/terminal-render.gif" \
  --font-family 'DejaVu Sans Mono' --font-size 26 --line-height 1.2 \
  --theme github-dark --fps-cap 12 --idle-time-limit 100000 \
  --last-frame-duration 3 --no-loop > "$ROOT/render.log" 2>&1
python3 - "$ROOT" <<'PY'
import json,sys
from pathlib import Path
root=Path(sys.argv[1]); report=json.loads((root/'source/demo-evidence.json').read_text())
chapters=report['chapters']; chunks=[';FFMETADATA1','title=Local AI Agent Harness v0.1.0 — Real CLI Demo','comment=Real release commands and live OpenRouter inference. Scripted typing. Silent on-screen explanations. Not an Ollama inference demo.']
for i,chapter in enumerate(chapters):
    end=chapters[i+1]['time'] if i+1<len(chapters) else report['duration']+3
    chunks.extend(['[CHAPTER]','TIMEBASE=1/1000',f'START={round(chapter["time"]*1000)}',f'END={round(end*1000)}','title='+chapter['title']])
(root/'source/chapters.ffmetadata').write_text('\n'.join(chunks)+'\n')
PY
printf 'Encoding readable 1080p H.264 MP4...\n'
ffmpeg -hide_banner -y -ignore_loop 1 -i "$ROOT/terminal-render.gif" \
  -i "$ROOT/source/chapters.ffmetadata" -map 0:v:0 -map_metadata 1 \
  -vf 'fps=24,scale=1920:1080:force_original_aspect_ratio=decrease:flags=lanczos,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=0x0d1117,setsar=1' \
  -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -an \
  -movflags +faststart "$ROOT/local-ai-agent-harness-demo.mp4" \
  > "$ROOT/encode.log" 2>&1
ffprobe -v error -show_format -show_streams -show_chapters -of json \
  "$ROOT/local-ai-agent-harness-demo.mp4" > "$ROOT/source/video-metadata.json"
python3 - "$ROOT" <<'PY'
import json,sys,subprocess
from pathlib import Path
root=Path(sys.argv[1]); meta=json.loads((root/'source/video-metadata.json').read_text()); streams=meta['streams']; video=next(s for s in streams if s['codec_type']=='video'); report=json.loads((root/'source/demo-evidence.json').read_text())
assert video['width']==1920 and video['height']==1080 and video['codec_name']=='h264' and video['pix_fmt']=='yuv420p'
assert len(meta['chapters'])==7 and not any(s['codec_type']=='audio' for s in streams)
assert abs(float(meta['format']['duration'])-report['duration'])<8
(root/'qa').mkdir(exist_ok=True)
for i,chapter in enumerate(report['chapters']):
    end=report['chapters'][i+1]['time'] if i+1<len(report['chapters']) else report['duration']
    time=max(chapter['time']+1,end-2)
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(time),'-i',str(root/'local-ai-agent-harness-demo.mp4'),'-frames:v','1',str(root/f'qa/chapter-{i+1}.png')],check=True)
from PIL import Image,ImageDraw
sheet=Image.new('RGB',(1280,4*382),'#0d1117'); draw=ImageDraw.Draw(sheet)
for i,chapter in enumerate(report['chapters']):
    frame=Image.open(root/f'qa/chapter-{i+1}.png').resize((640,360))
    x=(i%2)*640;y=(i//2)*382;sheet.paste(frame,(x,y));draw.text((x+10,y+364),f'{i+1}. {chapter["title"]}',fill='#c9d1d9')
sheet.save(root/'qa/contact-sheet.jpg',quality=92)
print(f'Video verified: {video["width"]}x{video["height"]}, H.264, {meta["format"]["duration"]}s, seven chapters, silent.')
PY
printf 'Checking full MP4 decode...\n'
ffmpeg -v error -i "$ROOT/local-ai-agent-harness-demo.mp4" -f null - \
  > "$ROOT/decode.log" 2>&1
printf 'Rendering and file-integrity checks passed.\n'
