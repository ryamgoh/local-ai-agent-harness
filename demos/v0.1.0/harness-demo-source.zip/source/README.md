# Local AI Agent Harness v0.1.0 — recorded demo

This is an actual CLI recording of the published `v0.1.0` npm-installable GitHub Release. The host, Python notes server, and Node guard hook run in an isolated Linux sandbox. The agent scene uses **live OpenRouter inference with `openai/gpt-4.1-mini` through the Vercel AI SDK**, not a scripted model answer. Ollama compatibility is mentioned but local-model inference is not demonstrated.

The walkthrough shows an empty baseline, MCP tools added by Python, a Node policy hook redacting a synthetic token before a write, denial that prevents a file from being created even with `--yes`, live search-based inference, and disable/enable removing/restoring tools. All shown command outputs come from the real release executable. Command typing and chapter headings are scripted for readability; no outcomes are fabricated. The installed package was prepared before recording.

The finished MP4 is silent, with on-screen explanations and embedded chapter metadata. The raw `.cast` is a replayable text terminal recording. No recording was uploaded to asciinema.org or another public host. Only synthetic note data is sent to OpenRouter; API credentials are kept in the environment and their values are checked absent from the cast and evidence. The `--yes` installations in this demo apply to the already-reviewed bundled proof plugins, not unknown code. Declared plugin permissions are consent information, not an OS sandbox.

## Replay

```sh
asciinema play local-ai-agent-harness.cast
```

Install asciinema locally if needed; the recording used version 2.4.0. The raw terminal geometry is 112 columns by 32 rows. The MP4 requires no special player beyond H.264 support.

## Re-record

`record-demo.py` expects this directory to be `source/` inside a demo folder. It creates and resets only `workspace/state` under that demo folder. Place an isolated global npm installation of the release under `runtime/` first:

```sh
npm install --global --prefix "$PWD/runtime" --ignore-scripts \
  ./local-ai-agent-harness-0.1.0.tgz
# Supply OPENROUTER_API_KEY via your own secret manager; do not record its value.
asciinema rec --quiet --cols 112 --rows 32 --env SHELL,TERM \
  --command "python3 $PWD/source/record-demo.py" local-ai-agent-harness.cast
```

Recording requires Python 3.11+, uv, the released proof plugins, and the model credential. It sends synthetic prompts/tool results to the hosted provider and can incur charges. Do not substitute real sensitive notes. `demo-evidence.json` stores the executed commands, captured outputs, expected exit codes, assertion outcomes, and chapter timestamps—not credentials.

For rendering, install `agg` under `tools/agg` or set `AGG` to its executable path, install FFmpeg/ffprobe and Pillow, then run `bash source/render-demo.sh` from the demo folder. Rendering preserves timing, except that terminal frames are sampled at up to 12 fps before 24 fps MP4 encoding; an extra ending hold is added. No playback speed-up is applied.

Powered by [asciinema](https://github.com/asciinema/asciinema), [agg](https://github.com/asciinema/agg), and [FFmpeg](https://github.com/FFmpeg/FFmpeg). Official tool documentation: [recording](https://docs.asciinema.org/manual/cli/usage/) and [agg](https://docs.asciinema.org/manual/agg/).
